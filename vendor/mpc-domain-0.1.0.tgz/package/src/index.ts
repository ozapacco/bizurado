// ============================================================
// MOTOR DE PROGRESSÃO COGNITIVA — Domain Types
// ============================================================
// Fonte: CONSTITUTION.md, DOMAIN-MODEL.md, PRD.md
// Invariantes: todas as DOM-INV, STATE-INV, CONTENT-INV, OBJ-INV, KNOW-INV
// ============================================================

// ─── ENUMS ───────────────────────────────────────────────────

export enum NodeState {
  N0_NOT_SEEN = "N0_NOT_SEEN",
  N1_EXPOSED = "N1_EXPOSED",
  N2_UNDERSTOOD = "N2_UNDERSTOOD",
  N3_RETRIEVABLE = "N3_RETRIEVABLE",
  N4_APPLICABLE = "N4_APPLICABLE",
  N5_STABLE = "N5_STABLE",
  N6_EXAM_READY = "N6_EXAM_READY",
}

export enum NodeRisk {
  UNKNOWN = "UNKNOWN",
  LOW = "LOW",
  MODERATE = "MODERATE",
  HIGH = "HIGH",
  CRITICAL = "CRITICAL",
}

export enum NodeType {
  DOMAIN = "DOMAIN",
  TOPIC = "TOPIC",
  SUBTOPIC = "SUBTOPIC",
  CONCEPT = "CONCEPT",
  RULE = "RULE",
  EXCEPTION = "EXCEPTION",
  PROCEDURE = "PROCEDURE",
  CLASSIFICATION = "CLASSIFICATION",
  DISTINCTION = "DISTINCTION",
  JURISPRUDENCE = "JURISPRUDENCE",
  NUMERIC_FACT = "NUMERIC_FACT",
  SKILL = "SKILL",
}

export enum NodeStatus {
  DRAFT = "DRAFT",
  ACTIVE = "ACTIVE",
  DEPRECATED = "DEPRECATED",
  MERGED = "MERGED",
  ARCHIVED = "ARCHIVED",
}

export enum EdgeType {
  PART_OF = "PART_OF",
  REQUIRES = "REQUIRES",
  PRECEDES = "PRECEDES",
  CONTRASTS_WITH = "CONTRASTS_WITH",
  CONFUSED_WITH = "CONFUSED_WITH",
  EXCEPTION_OF = "EXCEPTION_OF",
  APPLIES_TO = "APPLIES_TO",
  RELATED_TO = "RELATED_TO",
  EXAMPLE_OF = "EXAMPLE_OF",
  SUPERSEDES = "SUPERSEDES",
}

export enum PrerequisiteType {
  HARD = "HARD",
  SOFT = "SOFT",
  RECOMMENDED = "RECOMMENDED",
}

export enum CardClass {
  A = "A",
  B = "B",
  C = "C",
  UNCLASSIFIED = "UNCLASSIFIED",
}

export enum CardStatus {
  DRAFT = "DRAFT",
  ACTIVE = "ACTIVE",
  SUSPENDED = "SUSPENDED",
  VAULTED = "VAULTED",
  DEPRECATED = "DEPRECATED",
  MERGED = "MERGED",
}

export enum CognitiveRole {
  MAP = "MAP",
  DEFINITION = "DEFINITION",
  ATOMIC = "ATOMIC",
  CONTRAST = "CONTRAST",
  BRIDGE = "BRIDGE",
  EXCEPTION = "EXCEPTION",
  DEADLINE = "DEADLINE",
  JURISPRUDENCE = "JURISPRUDENCE",
  QUESTION = "QUESTION",
  ERROR_DEFENSE = "ERROR_DEFENSE",
  MNEMONIC = "MNEMONIC",
  APPLICATION = "APPLICATION",
  PROCEDURE = "PROCEDURE",
  CLASSIFICATION = "CLASSIFICATION",
}

export enum ActionType {
  ADVANCE_NODE = "ADVANCE_NODE",
  RETAIN_NODE = "RETAIN_NODE",
  VALIDATE_NODE = "VALIDATE_NODE",
  ANSWER_QUESTIONS = "ANSWER_QUESTIONS",
  REVIEW_FLASHCARDS = "REVIEW_FLASHCARDS",
  COMPARE_NODES = "COMPARE_NODES",
  SELF_EXPLAIN = "SELF_EXPLAIN",
  REPAIR_ERROR = "REPAIR_ERROR",
  CLOSE_SESSION = "CLOSE_SESSION",
}

export enum EvidenceEventType {
  CONTENT_EXPOSURE = "CONTENT_EXPOSURE",
  FLASHCARD_REVIEW = "FLASHCARD_REVIEW",
  QUESTION_ATTEMPT = "QUESTION_ATTEMPT",
  SELF_EXPLANATION = "SELF_EXPLANATION",
  NODE_RECALL = "NODE_RECALL",
  SESSION_ABANDONED = "SESSION_ABANDONED",
  SESSION_COMPLETED = "SESSION_COMPLETED",
  MANUAL_CONFIDENCE = "MANUAL_CONFIDENCE",
  ERROR_CLASSIFIED = "ERROR_CLASSIFIED",
}

export enum ErrorType {
  E1_UNKNOWN = "E1_UNKNOWN",
  E2_FORGOTTEN = "E2_FORGOTTEN",
  E3_CONFUSION = "E3_CONFUSION",
  E4_READING = "E4_READING",
  E5_STRATEGY = "E5_STRATEGY",
  E6_GUESS = "E6_GUESS",
}

export enum ObjectiveType {
  SPECIFIC_EXAM = "SPECIFIC_EXAM",
  CAREER_BASE = "CAREER_BASE",
  PRE_NOTICE = "PRE_NOTICE",
  POST_NOTICE = "POST_NOTICE",
  CUSTOM = "CUSTOM",
}

export enum ObjectiveStatus {
  DRAFT = "DRAFT",
  ACTIVE = "ACTIVE",
  PAUSED = "PAUSED",
  COMPLETED = "COMPLETED",
  ARCHIVED = "ARCHIVED",
}

export enum ExamStatus {
  EXPECTED = "EXPECTED",
  ANNOUNCED = "ANNOUNCED",
  OPEN = "OPEN",
  SCHEDULED = "SCHEDULED",
  COMPLETED = "COMPLETED",
  CANCELLED = "CANCELLED",
}

export enum SessionPlanStatus {
  GENERATED = "GENERATED",
  STARTED = "STARTED",
  COMPLETED = "COMPLETED",
  PARTIALLY_COMPLETED = "PARTIALLY_COMPLETED",
  ABANDONED = "ABANDONED",
  EXPIRED = "EXPIRED",
}

export enum SessionActionStatus {
  PENDING = "PENDING",
  STARTED = "STARTED",
  COMPLETED = "COMPLETED",
  SKIPPED = "SKIPPED",
  INTERRUPTED = "INTERRUPTED",
  REPLACED = "REPLACED",
}

export enum CoverageStatus {
  NOT_COVERED = "NOT_COVERED",
  EXPOSED = "EXPOSED",
  ACQUIRED = "ACQUIRED",
  MASTERED = "MASTERED",
}

export enum DebtZone {
  NORMAL = "NORMAL",
  ALERT = "ALERT",
  CRITICAL = "CRITICAL",
}

export enum EnginePhase {
  LOW_COVERAGE = "LOW_COVERAGE",
  MID_COVERAGE = "MID_COVERAGE",
  HIGH_COVERAGE = "HIGH_COVERAGE",
  PRE_EXAM = "PRE_EXAM",
  RECOVERY = "RECOVERY",
}

export enum DeadlineMode {
  NORMAL = "NORMAL",
  PRE_EXAM = "PRE_EXAM",
  EMERGENCY = "EMERGENCY",
}

export enum AssetType {
  FLASHCARD = "FLASHCARD",
  QUESTION = "QUESTION",
  DOCUMENT = "DOCUMENT",
  VIDEO = "VIDEO",
  SUMMARY = "SUMMARY",
  EXERCISE = "EXERCISE",
  CASE = "CASE",
  MIND_MAP = "MIND_MAP",
  NOTE = "NOTE",
}

export enum FlashcardNodeRelationship {
  PRIMARY = "PRIMARY",
  SECONDARY = "SECONDARY",
  CONTRAST = "CONTRAST",
  SUPPORT = "SUPPORT",
  EXCEPTION = "EXCEPTION",
  APPLICATION = "APPLICATION",
}

export enum QuestionNodeRelationship {
  PRIMARY_TEST = "PRIMARY_TEST",
  SECONDARY_TEST = "SECONDARY_TEST",
  DISTRACTOR = "DISTRACTOR",
  REQUIRES = "REQUIRES",
  CONFUSION_TRIGGER = "CONFUSION_TRIGGER",
}

// ─── VALUE OBJECTS ──────────────────────────────────────────

export interface CRASScores {
  comprehension: number
  retrieval: number
  application: number
  stability: number
}

export interface CRASConfidence {
  comprehension: number
  retrieval: number
  application: number
  stability: number
}

export interface FactorBreakdown {
  factor: string
  value: number
  weight: number
  contribution: number
}

export interface ReasonCodeEntry {
  code: string
  contribution: number
  label: string
}

export interface TimeFitness {
  ratio: number
  score: number
  chunkable: boolean
}

export interface EvidenceSummary {
  eventType: EvidenceEventType
  nodeId: string
  timestamp: string
  confidence: number
  correct?: boolean
  errorType?: ErrorType
  guessed?: boolean
}

export interface AssetAvailability {
  hasFlashcards: boolean
  hasQuestions: boolean
  hasDocuments: boolean
  flashcardCount: number
  questionCount: number
  classARatio: number
  estimatedRetainSeconds: number
}

// ─── ENTITIES ───────────────────────────────────────────────

export interface KnowledgeNode {
  id: string
  slug: string
  title: string
  description: string
  disciplineId: string
  parentNodeId: string | null
  nodeType: NodeType
  depth: number
  status: NodeStatus
  intrinsicDifficulty: number
  estimatedAcquisitionCostMinutes: number
  estimatedValidationCostMinutes: number
  confusabilityScore: number
  centralityScore: number
  createdAt: string
  updatedAt: string
}

export interface KnowledgeNodeEdge {
  id: string
  sourceNodeId: string
  targetNodeId: string
  edgeType: EdgeType
  weight: number
  confidence: number
  origin: string
  status: string
  createdAt: string
}

export interface PrerequisitePolicy {
  sourceNodeId: string
  targetNodeId: string
  prerequisiteType: PrerequisiteType
}

export interface StudyObjective {
  id: string
  userId: string
  title: string
  description: string
  objectiveType: ObjectiveType
  status: ObjectiveStatus
  targetDate: string | null
  examId: string | null
  syllabusId: string | null
  createdAt: string
  updatedAt: string
}

export interface SyllabusNodeWeight {
  syllabusId: string
  knowledgeNodeId: string
  weight: number
  incidenceScore: number | null
  mandatory: boolean
  source: string
  confidence: number
}

export interface UserNodeState {
  userId: string
  nodeId: string
  comprehensionScore: number
  retrievalScore: number
  applicationScore: number
  stabilityScore: number
  state: NodeState
  risk: NodeRisk
  confidence: number
  firstExposureAt: string | null
  lastActivityAt: string | null
  lastRetrievalAt: string | null
  lastValidationAt: string | null
  evidenceCount: number
  snapshotVersion: number
}

export interface MasterySnapshot {
  id: string
  userId: string
  nodeId: string
  C: number
  R: number
  A: number
  S: number
  state: NodeState
  risk: NodeRisk
  confidence: number
  engineVersion: string
  policyVersion: string
  evidenceCursor: string
  createdAt: string
}

export interface EvidenceEvent {
  id: string
  userId: string
  nodeId: string
  eventType: EvidenceEventType
  timestamp: string
  payload: Record<string, unknown>
  source: string
  sessionId: string | null
  schemaVersion: string
}

export interface CapacityObservation {
  userId: string
  date: string
  availableMinutesReported: number
  studiedMinutes: number
  completedActions: number
  interruptedActions: number
  zeroDay: boolean
}

export interface CapacityProfile {
  userId: string
  expectedDailyMinutes: number
  expectedWeeklyMinutes: number
  variance: number
  confidence: number
  calculatedAt: string
  modelVersion: string
}

export interface ReviewDebtSnapshot {
  userId: string
  projectedCapacityMinutes: number
  projectedMaintenanceMinutes: number
  criticalMinutes: number
  strategicMinutes: number
  peripheralMinutes: number
  debtRatio: number
  zone: DebtZone
  horizonDays: number
  createdAt: string
}

export interface Flashcard {
  id: string
  externalId: string | null
  front: string
  back: string
  contentHash: string
  deck: string
  tags: string[]
  sourceDocumentId: string | null
  contentBlockId: string | null
  sourceMode: string
  cardClass: CardClass
  cognitiveRole: CognitiveRole
  status: CardStatus
  estimatedCostSeconds: number
  createdAt: string
  updatedAt: string
}

export interface FlashcardNodeLink {
  flashcardId: string
  nodeId: string
  relationshipType: FlashcardNodeRelationship
  weight: number
  confidence: number
  origin: string
}

export interface Question {
  id: string
  externalId: string | null
  statement: string
  options: Record<string, string>
  correctAnswer: string
  explanation: string
  examBoard: string
  year: number
  difficulty: number
  sourceDocumentId: string | null
  status: string
}

export interface QuestionAttempt {
  id: string
  userId: string
  questionId: string
  timestamp: string
  correct: boolean
  selectedAnswer: string
  responseTimeMs: number
  confidence: number
  guessed: boolean
  errorType: ErrorType | null
  sessionId: string | null
}

// ─── ENGINE TYPES ───────────────────────────────────────────

export interface ObjectiveContext {
  objectiveId: string
  objectiveType: ObjectiveType
  targetDate: string | null
  examProximityDays: number | null
}

export interface NodeDecisionState {
  nodeId: string
  nodeType: NodeType
  state: NodeState
  risk: NodeRisk
  stateConfidence: number
  C: number
  R: number
  A: number
  S: number
  CConfidence: number
  RConfidence: number
  AConfidence: number
  SConfidence: number
  objectiveWeight: number
  incidenceScore: number | null
  coverageStatus: CoverageStatus
  prerequisiteStatus: PrerequisiteStatus
  continuityScore: number
  forgettingRisk: number
  masteryUncertainty: number
  confusabilityScore: number
  recentErrorScore: number
  highConfidenceErrorScore: number
  daysSinceExposure: number | null
  daysSinceRetrieval: number | null
  daysSinceValidation: number | null
  estimatedAdvanceMinutes: number
  estimatedRetainMinutes: number
  estimatedValidateMinutes: number
  availableAssets: AssetAvailability
  evidenceCoverage: EvidenceCoverage
  activeAcquisition: boolean
}

export interface PrerequisiteStatus {
  hardMet: boolean
  softScore: number
  blockedBy: string[]
}

export interface EvidenceCoverage {
  hasExposure: boolean
  hasComprehension: boolean
  hasRetrieval: boolean
  hasApplication: boolean
  distributedDays: number
  spanDays: number
}

export interface ActiveAcquisitionNode {
  nodeId: string
  startedAt: string
  estimatedTotalMinutes: number
  elapsedMinutes: number
}

export interface SessionHistorySummary {
  lastSessionDate: string | null
  recentCompletionRate: number
  daysSinceLastSession: number | null
  recentOverrideRate: number
}

export interface EngineConstraints {
  minimumAdvanceMinutes: number
  minimumAdvanceRatio: number
  maxActiveAcquisitionNodes: number
  allowCriticalOverride: boolean
  maxSingleNodeSessionRatio: number
  maxQueueShare: Record<string, number>
  objectiveDeadlineMode: DeadlineMode
}

export interface ReviewDebtState {
  debtRatio: number
  zone: DebtZone
  criticalMinutes: number
  strategicMinutes: number
  peripheralMinutes: number
  projectedCapacityMinutes: number
  projectedMaintenanceMinutes: number
}

// ─── ENGINE INPUT / OUTPUT ──────────────────────────────────

export interface EngineInput {
  userId: string
  objectiveId: string
  availableMinutes: number
  now: string
  objective: ObjectiveContext
  nodes: NodeDecisionState[]
  capacityProfile: CapacityProfile
  reviewDebt: ReviewDebtState
  recentEvidence: EvidenceSummary[]
  activeAcquisitionNodes: ActiveAcquisitionNode[]
  sessionHistory: SessionHistorySummary
  constraints: EngineConstraints
  engineVersion: string
  policyVersion: string
}

export interface CandidateAction {
  actionType: ActionType
  nodeId: string
  estimatedMinutes: number
  baseScore: number
  bonuses: BonusEntry[]
  penalties: PenaltyEntry[]
  finalScore: number
  factorBreakdown: FactorBreakdown[]
  reasonCodes: string[]
  causalFit: number
  timeEfficiency: number
}

export interface BonusEntry {
  id: string
  label: string
  value: number
}

export interface PenaltyEntry {
  id: string
  label: string
  value: number
}

export interface RankedCandidate extends CandidateAction {
  rank: number
}

export interface QueueSnapshots {
  advance: RankedCandidate[]
  retain: RankedCandidate[]
  validate: RankedCandidate[]
}

export interface EngineDecision {
  decisionId: string
  engineRunId: string
  actionType: ActionType
  nodeId: string
  score: number
  factorBreakdown: FactorBreakdown[]
  reasonCodes: string[]
  rank: number
  explanation: Explanation
}

export interface Explanation {
  human: string
  detailed: string[]
  technical: Record<string, unknown>
}

export interface SessionPlan {
  id: string
  userId: string
  objectiveId: string
  engineRunId: string
  availableMinutes: number
  plannedMinutes: number
  actions: SessionActionPlan[]
  phase: EnginePhase
  status: SessionPlanStatus
  createdAt: string
  expiresAt: string
}

export interface SessionActionPlan {
  id: string
  sequence: number
  actionType: ActionType
  nodeId: string
  plannedMinutes: number
  explanation: Explanation
  reasonCodes: string[]
  finalScore: number
}

export interface InvariantCheckResult {
  invariantId: string
  name: string
  passed: boolean
  message: string | null
}

export interface EngineOutput {
  sessionPlan: SessionPlan
  queueSnapshots: QueueSnapshots
  decisions: EngineDecision[]
  invariantChecks: InvariantCheckResult[]
  engineVersion: string
  policyVersion: string
  inputHash: string
  phase: EnginePhase
}

// ─── STATE MACHINE TYPES ────────────────────────────────────

export interface StateTransition {
  from: NodeState
  to: NodeState
  reasonCodes: string[]
  scores: CRASScores
  confidence: CRASConfidence
}

export interface StateThresholds {
  promotion: Partial<Record<NodeState, number>>
  regression: Partial<Record<NodeState, number>>
}

export interface NodeStateResult {
  scores: CRASScores
  confidence: CRASConfidence
  state: NodeState
  risk: NodeRisk
}

export interface StateMachineConfig {
  hysteresisThresholds: Record<string, { promotion: number; regression: number }>
  minimumMeaningfulDelayHours: number
  minimumDistinctDays: number
  minimumSpanDays: number
  n6Thresholds: {
    C: number
    R: number
    A: number
    S: number
    confidence: number
  }
  nodeTypeOverrides: Partial<Record<NodeType, Partial<StateMachineConfig>>>
}

// ─── DEFAULT CONFIGURATIONS ─────────────────────────────────

export const DEFAULT_STATE_MACHINE_CONFIG: StateMachineConfig = {
  hysteresisThresholds: {
    N2: { promotion: 0.65, regression: 0.50 },
    N3: { promotion: 0.65, regression: 0.50 },
    N4: { promotion: 0.65, regression: 0.52 },
    N5: { promotion: 0.70, regression: 0.58 },
    N6: { promotion: 0.75, regression: 0.65 },
  },
  minimumMeaningfulDelayHours: 24,
  minimumDistinctDays: 3,
  minimumSpanDays: 14,
  n6Thresholds: {
    C: 0.75,
    R: 0.75,
    A: 0.72,
    S: 0.72,
    confidence: 0.70,
  },
  nodeTypeOverrides: {},
}

export const DEFAULT_ENGINE_CONSTRAINTS: EngineConstraints = {
  minimumAdvanceMinutes: 5,
  minimumAdvanceRatio: 0.25,
  maxActiveAcquisitionNodes: 3,
  allowCriticalOverride: false,
  maxSingleNodeSessionRatio: 0.75,
  maxQueueShare: {
    advance: 0.60,
    retain: 0.60,
    validate: 0.60,
  },
  objectiveDeadlineMode: DeadlineMode.NORMAL,
}

export const PHASE_COVERAGE_THRESHOLDS = {
  LOW_COVERAGE: 0.35,
  HIGH_COVERAGE: 0.70,
}

export const PHASE_TARGET_MIXES: Record<string, { advance: number; retain: number; validate: number }> = {
  LOW_COVERAGE: { advance: 0.50, retain: 0.30, validate: 0.20 },
  MID_COVERAGE: { advance: 0.40, retain: 0.30, validate: 0.30 },
  HIGH_COVERAGE: { advance: 0.25, retain: 0.30, validate: 0.45 },
}

export const DEBT_ZONE_THRESHOLDS = {
  NORMAL: 0.40,
  ALERT: 0.55,
}

export const COVERAGE_GAP_BY_STATE: Record<NodeState, number> = {
  [NodeState.N0_NOT_SEEN]: 1.00,
  [NodeState.N1_EXPOSED]: 0.85,
  [NodeState.N2_UNDERSTOOD]: 0.55,
  [NodeState.N3_RETRIEVABLE]: 0.25,
  [NodeState.N4_APPLICABLE]: 0.10,
  [NodeState.N5_STABLE]: 0.03,
  [NodeState.N6_EXAM_READY]: 0.00,
}

export const CONTINUITY_DECAY: { maxHours: number; score: number }[] = [
  { maxHours: 24, score: 1.00 },
  { maxHours: 72, score: 0.75 },
  { maxHours: 168, score: 0.35 },
  { maxHours: Infinity, score: 0.00 },
]

export const CLOSING_RESERVE: { minMinutes: number; reserve: number }[] = [
  { minMinutes: 15, reserve: 1 },
  { minMinutes: 25, reserve: 2 },
  { minMinutes: 40, reserve: 3 },
  { minMinutes: 60, reserve: 4 },
  { minMinutes: 90, reserve: 5 },
]
