// ─── NODE STATE MACHINE ─────────────────────────────────────
// Fonte: NODE-STATE-MACHINE.spec.md, CONSTITUTION.md (§5-6)
// Invariantes: STATE-INV-001 a 004, DOM-INV-004, DOM-INV-005

import {
  NodeState, NodeRisk, NodeType, CRASScores, CRASConfidence,
  NodeDecisionState, EvidenceCoverage, StateMachineConfig,
  DEFAULT_STATE_MACHINE_CONFIG, NodeStateResult, UserNodeState,
} from "@mpc/domain"

export function calculateCRAS(
  evidence: EvidenceCoverage,
  config: StateMachineConfig = DEFAULT_STATE_MACHINE_CONFIG
): { scores: CRASScores; confidence: CRASConfidence } {
  const scores: CRASScores = {
    comprehension: evidence.hasExposure ? 0.5 : 0,
    retrieval: evidence.hasRetrieval ? 0.5 : 0,
    application: evidence.hasApplication ? 0.5 : 0,
    stability: evidence.spanDays >= config.minimumSpanDays ? 0.5 : 0,
  }
  const confidence: CRASConfidence = {
    comprehension: evidence.hasComprehension ? 0.6 : 0.2,
    retrieval: evidence.hasRetrieval && evidence.distributedDays >= 1 ? 0.6 : 0.2,
    application: evidence.hasApplication ? 0.6 : 0.1,
    stability: evidence.distributedDays >= config.minimumDistinctDays ? 0.6 : 0.1,
  }
  return { scores, confidence }
}

export function highestPossibleState(
  scores: CRASScores,
  confidence: CRASConfidence,
  evidence: EvidenceCoverage,
  config: StateMachineConfig = DEFAULT_STATE_MACHINE_CONFIG
): NodeState {
  const h = config.hysteresisThresholds

  if (scores.stability >= h.N6?.promotion && confidence.stability >= 0.6 && evidence.distributedDays >= config.minimumDistinctDays && evidence.spanDays >= config.minimumSpanDays) {
    if (scores.application >= h.N4?.promotion) return NodeState.N6_EXAM_READY
    return NodeState.N5_STABLE
  }
  if (scores.stability >= h.N5?.promotion && confidence.stability >= 0.6 && evidence.distributedDays >= config.minimumDistinctDays && evidence.spanDays >= config.minimumSpanDays) {
    return NodeState.N5_STABLE
  }
  if (scores.application >= h.N4?.promotion && confidence.application >= 0.55 && evidence.hasApplication) {
    return NodeState.N4_APPLICABLE
  }
  if (scores.retrieval >= h.N3?.promotion && confidence.retrieval >= 0.5 && evidence.hasRetrieval) {
    return NodeState.N3_RETRIEVABLE
  }
  if (scores.comprehension >= h.N2?.promotion && confidence.comprehension >= 0.45 && evidence.hasComprehension) {
    return NodeState.N2_UNDERSTOOD
  }
  if (evidence.hasExposure) {
    return NodeState.N1_EXPOSED
  }
  return NodeState.N0_NOT_SEEN
}

export function applyStateCeilings(
  candidateState: NodeState,
  evidence: EvidenceCoverage
): NodeState {
  if (!evidence.hasApplication && (candidateState === NodeState.N4_APPLICABLE || candidateState === NodeState.N5_STABLE || candidateState === NodeState.N6_EXAM_READY)) {
    return NodeState.N3_RETRIEVABLE
  }
  if (!evidence.hasRetrieval && candidateState === NodeState.N3_RETRIEVABLE) {
    return NodeState.N2_UNDERSTOOD
  }
  return candidateState
}

export function applyHysteresis(
  previousState: NodeState,
  candidateState: NodeState,
  scores: CRASScores,
  config: StateMachineConfig = DEFAULT_STATE_MACHINE_CONFIG
): NodeState {
  if (candidateState === previousState) return previousState

  const stateOrder = [
    NodeState.N0_NOT_SEEN, NodeState.N1_EXPOSED, NodeState.N2_UNDERSTOOD,
    NodeState.N3_RETRIEVABLE, NodeState.N4_APPLICABLE, NodeState.N5_STABLE,
    NodeState.N6_EXAM_READY,
  ]

  const prevIdx = stateOrder.indexOf(previousState)
  const candIdx = stateOrder.indexOf(candidateState)
  if (prevIdx === -1 || candIdx === -1) return candidateState

  if (candIdx > prevIdx) {
    return candidateState
  }

  if (candIdx < prevIdx) {
    const regressionKey = previousState.replace("_", "").replace("N", "N")
    const shortKey = `N${stateOrder[prevIdx].charAt(1)}`
    const thresholds = config.hysteresisThresholds
    const regressionThreshold = thresholds[shortKey]?.regression ?? 0.40

    if (previousState === NodeState.N2_UNDERSTOOD && scores.comprehension < regressionThreshold) return candidateState
    if (previousState === NodeState.N3_RETRIEVABLE && scores.retrieval < regressionThreshold) return candidateState
    if (previousState === NodeState.N4_APPLICABLE && scores.application < regressionThreshold) return candidateState
    if (previousState === NodeState.N5_STABLE && scores.stability < regressionThreshold) return candidateState
    if (previousState === NodeState.N6_EXAM_READY && scores.stability < (thresholds[shortKey]?.regression ?? 0.65)) return candidateState

    return previousState
  }

  return candidateState
}

export function calculateRisk(
  node: Pick<NodeDecisionState, 'state' | 'R' | 'A' | 'forgettingRisk' | 'objectiveWeight' | 'recentErrorScore' | 'confusabilityScore' | 'masteryUncertainty' | 'stateConfidence'>,
  daysSinceLastActivity: number | null,
  examProximityDays: number | null
): NodeRisk {
  let riskScore = 0

  riskScore += node.forgettingRisk * 0.25
  riskScore += (1 - node.stateConfidence) * 0.20
  riskScore += node.recentErrorScore * 0.20
  riskScore += node.masteryUncertainty * 0.15
  riskScore += node.confusabilityScore * 0.10
  riskScore += node.objectiveWeight * 0.10

  if (examProximityDays !== null && examProximityDays < 30) {
    riskScore += (1 - examProximityDays / 30) * 0.10
  }
  if (daysSinceLastActivity !== null && daysSinceLastActivity > 14) {
    riskScore += Math.min(0.15, daysSinceLastActivity / 100)
  }

  riskScore = Math.min(1, Math.max(0, riskScore))

  if (riskScore >= 0.75) return NodeRisk.CRITICAL
  if (riskScore >= 0.55) return NodeRisk.HIGH
  if (riskScore >= 0.35) return NodeRisk.MODERATE
  if (riskScore >= 0.10) return NodeRisk.LOW
  return NodeRisk.UNKNOWN
}

export function deriveNodeState(
  previousState: NodeState,
  evidence: EvidenceCoverage,
  objectiveContext?: { targetDate: string | null; examProximityDays: number | null },
  config: StateMachineConfig = DEFAULT_STATE_MACHINE_CONFIG
): NodeStateResult {
  const { scores, confidence } = calculateCRAS(evidence, config)

  let candidateState = highestPossibleState(scores, confidence, evidence, config)

  candidateState = applyStateCeilings(candidateState, evidence)

  const finalState = applyHysteresis(previousState, candidateState, scores, config)

  const risk = calculateRisk(
    {
      state: finalState,
      R: scores.retrieval,
      A: scores.application,
      forgettingRisk: 1 - scores.retrieval,
      objectiveWeight: 0.5,
      recentErrorScore: 0,
      confusabilityScore: 0,
      masteryUncertainty: 1 - Math.min(...Object.values(confidence)),
      stateConfidence: Math.min(...Object.values(confidence)),
    },
    null,
    objectiveContext?.examProximityDays ?? null
  )

  return { scores, confidence, state: finalState, risk }
}

export function regressionCheck(
  currentState: NodeState,
  currentScores: CRASScores,
  newEvidence: EvidenceCoverage,
  config: StateMachineConfig = DEFAULT_STATE_MACHINE_CONFIG
): boolean {
  const stateOrder = [
    NodeState.N0_NOT_SEEN, NodeState.N1_EXPOSED, NodeState.N2_UNDERSTOOD,
    NodeState.N3_RETRIEVABLE, NodeState.N4_APPLICABLE, NodeState.N5_STABLE,
    NodeState.N6_EXAM_READY,
  ]
  const currentIdx = stateOrder.indexOf(currentState)
  if (currentIdx <= 1) return false

  const shortKey = `N${currentState.charAt(1)}`
  const threshold = config.hysteresisThresholds[shortKey]?.regression ?? 0.40

  if (currentState === NodeState.N2_UNDERSTOOD && currentScores.comprehension < threshold) return true
  if (currentState === NodeState.N3_RETRIEVABLE && currentScores.retrieval < threshold) return true
  if (currentState === NodeState.N4_APPLICABLE && currentScores.application < threshold) return true
  if (currentState === NodeState.N5_STABLE && currentScores.stability < threshold) return true
  if (currentState === NodeState.N6_EXAM_READY && currentScores.stability < threshold) return true

  return false
}
