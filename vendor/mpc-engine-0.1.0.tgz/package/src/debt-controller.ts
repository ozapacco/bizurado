// ─── DEBT CONTROLLER ────────────────────────────────────────
// Fonte: CONSTITUTION (§4 INV-010), PRD (§28)
// Invariantes: DEBT-001, DEBT-002, DEBT-003

import { DebtZone, ReviewDebtState, DEBT_ZONE_THRESHOLDS } from "@mpc/domain"

export interface DebtControllerInput {
  projectedCapacityMinutes: number
  projectedMaintenanceMinutes: number
  criticalMinutes: number
  strategicMinutes: number
  peripheralMinutes: number
}

export interface DebtControllerOutput {
  debtRatio: number
  zone: DebtZone
  projectedMaintenanceMinutes: number
  criticalMinutes: number
  strategicMinutes: number
  peripheralMinutes: number
  recommendedActions: string[]
  adjustedCapacityMinutes: number
}

export function calculateDebtRatio(
  maintenance: number,
  capacity: number
): number {
  if (capacity <= 0) return 1.0
  return Math.min(1.0, maintenance / capacity)
}

export function determineDebtZone(debtRatio: number): DebtZone {
  if (debtRatio > DEBT_ZONE_THRESHOLDS.ALERT) return DebtZone.CRITICAL
  if (debtRatio > DEBT_ZONE_THRESHOLDS.NORMAL) return DebtZone.ALERT
  return DebtZone.NORMAL
}

export function runDebtController(input: DebtControllerInput): DebtControllerOutput {
  const debtRatio = calculateDebtRatio(input.projectedMaintenanceMinutes, input.projectedCapacityMinutes)
  const zone = determineDebtZone(debtRatio)
  const actions: string[] = []

  let adjustedMaintenance = input.projectedMaintenanceMinutes
  let adjustedCritical = input.criticalMinutes
  let adjustedStrategic = input.strategicMinutes
  let adjustedPeripheral = input.peripheralMinutes

  switch (zone) {
    case DebtZone.NORMAL:
      actions.push("Operação normal de liberação")
      break

    case DebtZone.ALERT:
      adjustedPeripheral = Math.round(adjustedPeripheral * 0.6)
      adjustedMaintenance = adjustedCritical + adjustedStrategic + adjustedPeripheral
      actions.push("Redução de cards periféricos (Classe C)")
      actions.push("Priorização de retenção estratégica")
      break

    case DebtZone.CRITICAL:
      adjustedPeripheral = 0
      adjustedStrategic = Math.round(adjustedStrategic * 0.5)
      adjustedMaintenance = adjustedCritical + adjustedStrategic
      actions.push("Bloqueio de novos cards Classe C")
      actions.push("Redução de cards Classe B periféricos")
      actions.push("Detecção de leeches/cards de alto custo")
      actions.push("Preservação do pulso mínimo de avanço")
      break
  }

  const adjustedCapacityMinutes = Math.round(
    input.projectedCapacityMinutes * (1 - debtRatio * 0.3)
  )

  return {
    debtRatio,
    zone,
    projectedMaintenanceMinutes: adjustedMaintenance,
    criticalMinutes: adjustedCritical,
    strategicMinutes: adjustedStrategic,
    peripheralMinutes: adjustedPeripheral,
    recommendedActions: actions,
    adjustedCapacityMinutes,
  }
}
