#!/usr/bin/env node
// ─── ENGINE LAB CLI ─────────────────────────────────────────
// Uso: npm run engine:lab -- <caminho-para-input.json>

import { readFileSync } from "node:fs"
import { generateSession } from "../index.js"

function usage(): never {
  console.error("Uso: npm run engine:lab -- <caminho-para-input.json>")
  process.exit(1)
}

function main(): void {
  const args = process.argv.slice(2)

  if (args.length === 0 || args[0].startsWith("--")) usage()

  const raw = readFileSync(args[0], "utf-8")
  const input = JSON.parse(raw)
  const output = generateSession(input)

  const plan = output.sessionPlan

  const advanceActions = plan.actions.filter(a => a.actionType === "ADVANCE_NODE")
  const retainActions = plan.actions.filter(a => a.actionType === "RETAIN_NODE")
  const validateActions = plan.actions.filter(a => a.actionType === "VALIDATE_NODE")
  const closeActions = plan.actions.filter(a => a.actionType === "CLOSE_SESSION")

  const fmt = (n: number) => (n * 100).toFixed(0) + "%"

  console.log("=".repeat(60))
  console.log("  MPC — MOTOR DE PROGRESSÃO COGNITIVA")
  console.log("=".repeat(60))
  console.log()
  console.log("  Engine  :", output.engineVersion)
  console.log("  Policy  :", output.policyVersion)
  console.log("  Hash    :", output.inputHash)
  console.log("  Phase   :", output.phase)
  console.log()
  console.log("  ── SESSION ──")
  console.log("  ID      :", plan.id)
  console.log("  Status  :", plan.status)
  console.log("  Time    :", `${plan.plannedMinutes}/${plan.availableMinutes} min (${(plan.plannedMinutes / plan.availableMinutes * 100).toFixed(0)}%)`)
  console.log()

  function printGroup(label: string, icon: string, actions: typeof plan.actions): void {
    if (!actions.length) return
    const total = actions.reduce((s, a) => s + a.plannedMinutes, 0)
    console.log(`  ${icon} ${label} (${actions.length})`)
    for (const a of actions) {
      console.log(`     ${a.sequence}. ${a.nodeId}`)
      console.log(`        ${a.plannedMinutes} min  \xB7  score ${fmt(a.finalScore)}  \xB7  ${a.explanation.human}`)
    }
    console.log(`     \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500`)
    console.log(`     Total: ${total} min`)
    console.log()
  }

  printGroup("ADVANCE", "\u25B6", advanceActions)
  printGroup("RETENTION", "\u25FB", retainActions)
  printGroup("VALIDATION", "\u2713", validateActions)
  printGroup("CLOSURE", "\u23F9", closeActions)

  console.log("  ── INVARIANT CHECKS ──")
  for (const chk of output.invariantChecks) {
    console.log(`  ${chk.passed ? "\u2713" : "\u2717"} ${chk.name}${chk.message ? "  \u2014  " + chk.message : ""}`)
  }
  console.log()

  console.log("  ── DECISIONS ──")
  for (const d of output.decisions) {
    console.log(`  ${d.rank}. ${d.actionType}  \xB7  ${d.nodeId}  \xB7  score ${fmt(d.score)}`)
    for (const rc of d.reasonCodes) console.log(`     \u2022 ${rc}`)
  }
  console.log()

  const ok = output.invariantChecks.every(c => c.passed)
  console.log(ok ? "  \u2713 All invariants passed." : "  \u2717 Some invariants FAILED.")
  console.log("=".repeat(60))
}

main()
