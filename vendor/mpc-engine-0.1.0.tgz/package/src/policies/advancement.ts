// ─── ADVANCEMENT POLICY ─────────────────────────────────────
// Fonte: ADVANCEMENT-POLICY.spec.md
// Policy ID: advance-policy@0.1.0

import {
  NodeDecisionState, ReviewDebtState, CandidateAction, ActionType,
  FactorBreakdown, BonusEntry, PenaltyEntry, EngineConstraints,
  COVERAGE_GAP_BY_STATE, CONTINUITY_DECAY, NodeState,
} from "@mpc/domain"

function hoursSince(date: string | null, now: string): number {
  if (!date) return Infinity
  return (new Date(now).getTime() - new Date(date).getTime()) / 3600000
}

function calcTimeFit(estimated: number, available: number): number {
  const ratio = estimated / available
  if (ratio <= 0.35) return 1.00
  if (ratio <= 0.60) return 0.90
  if (ratio <= 0.85) return 0.75
  if (ratio <= 1.00) return 0.60
  return 0.00
}

function calcContinuity(node: NodeDecisionState, now: string): number {
  if (node.continuityScore > 0) {
    const hoursSinceLast = hoursSince(null, now)
    if (hoursSinceLast <= 24) return Math.min(1.0, node.continuityScore * 1.0)
    if (hoursSinceLast <= 72) return Math.min(0.75, node.continuityScore * 0.75)
    if (hoursSinceLast <= 168) return Math.min(0.35, node.continuityScore * 0.35)
  }
  return node.continuityScore
}

function starvationBonus(node: NodeDecisionState): number {
  if (node.objectiveWeight < 0.5) return 0
  if (node.daysSinceExposure === null) return 0
  if (node.daysSinceExposure >= 30) return 0.10
  if (node.daysSinceExposure >= 14) return 0.05
  if (node.daysSinceExposure >= 7) return 0.02
  return 0
}

export function isAdvancementEligible(
  node: NodeDecisionState,
  constraints: EngineConstraints,
  debt: ReviewDebtState
): { eligible: boolean; reason: string | null } {
  if (node.objectiveWeight <= 0) {
    return { eligible: false, reason: "NO_OBJECTIVE_RELEVANCE" }
  }
  if (!node.prerequisiteStatus.hardMet) {
    return { eligible: false, reason: `HARD_PREREQUISITE_BLOCKED:${node.prerequisiteStatus.blockedBy.join(",")}` }
  }
  if (node.state === NodeState.N6_EXAM_READY) {
    return { eligible: false, reason: "ALREADY_MASTERED" }
  }
  if (!node.availableAssets.hasFlashcards && !node.availableAssets.hasDocuments) {
    return { eligible: false, reason: "ASSET_UNAVAILABLE" }
  }
  if (constraints.maxActiveAcquisitionNodes > 0 && node.activeAcquisition) {
    return { eligible: false, reason: "ALREADY_ACTIVE_ACQUISITION" }
  }
  return { eligible: true, reason: null }
}

export function rankAdvancement(
  node: NodeDecisionState,
  availableMinutes: number,
  debt: ReviewDebtState,
  constraints: EngineConstraints,
  now: string
): CandidateAction | null {
  const eligibility = isAdvancementEligible(node, constraints, debt)
  if (!eligibility.eligible) return null

  const estimatedMinutes = node.estimatedAdvanceMinutes
  const timeFit = calcTimeFit(estimatedMinutes, availableMinutes)
  if (timeFit <= 0 && estimatedMinutes > availableMinutes) return null

  const coverageGapValue = COVERAGE_GAP_BY_STATE[node.state] ?? 1.0
  const continuityValue = calcContinuity(node, now)
  const prerequisiteCentrality = node.confusabilityScore ?? 0.5

  const factors: FactorBreakdown[] = [
    { factor: "objectiveWeight", value: node.objectiveWeight, weight: 0.30, contribution: 0.30 * node.objectiveWeight },
    { factor: "coverageGap", value: coverageGapValue, weight: 0.25, contribution: 0.25 * coverageGapValue },
    { factor: "prerequisiteCentrality", value: prerequisiteCentrality, weight: 0.20, contribution: 0.20 * prerequisiteCentrality },
    { factor: "continuity", value: continuityValue, weight: 0.15, contribution: 0.15 * continuityValue },
    { factor: "timeFit", value: timeFit, weight: 0.10, contribution: 0.10 * timeFit },
  ]

  const baseScore = factors.reduce((s, f) => s + f.contribution, 0)

  const bonuses: BonusEntry[] = []

  if (continuityValue >= 0.75 && coverageGapValue >= 0.55) {
    bonuses.push({ id: "BONUS-A-001", label: "Continuity Chain", value: 0.05 })
  }

  const unlockScore = prerequisiteCentrality * 0.08
  if (unlockScore > 0.02) {
    bonuses.push({ id: "BONUS-A-002", label: "Unlock Bonus", value: Math.round(unlockScore * 100) / 100 })
  }

  const starve = starvationBonus(node)
  if (starve > 0) {
    bonuses.push({ id: "BONUS-A-004", label: "Starvation Protection", value: starve })
  }

  const penalties: PenaltyEntry[] = []

  if (debt.zone === "ALERT" || debt.zone === "CRITICAL") {
    const memoryCost = node.availableAssets.classARatio * 0.15
    if (memoryCost > 0.02) {
      penalties.push({ id: "PEN-A-003", label: "High Future Memory Cost", value: Math.round(memoryCost * 100) / 100 })
    }
  }

  if (!node.prerequisiteStatus.hardMet || node.prerequisiteStatus.softScore < 0.5) {
    penalties.push({ id: "PEN-A-004", label: "Weak Prerequisite", value: 0.08 })
  }

  if (!node.availableAssets.hasFlashcards && !node.availableAssets.hasDocuments) {
    penalties.push({ id: "PEN-A-005", label: "Asset Quality", value: 0.10 })
  }

  const totalBonuses = bonuses.reduce((s, b) => s + b.value, 0)
  const totalPenalties = penalties.reduce((s, p) => s + p.value, 0)

  const finalScore = Math.min(1, Math.max(0, baseScore + totalBonuses - totalPenalties))

  const reasonCodes: string[] = []
  if (node.objectiveWeight >= 0.7) reasonCodes.push("HIGH_OBJECTIVE_WEIGHT")
  if (coverageGapValue >= 0.8) reasonCodes.push("LARGE_COVERAGE_GAP")
  if (prerequisiteCentrality >= 0.7) reasonCodes.push("UNLOCKS_IMPORTANT_NODES")
  if (continuityValue >= 0.75) reasonCodes.push("CONTINUITY_CHAIN")
  if (timeFit >= 0.9) reasonCodes.push("GOOD_TIME_FIT")
  if (starve > 0) reasonCodes.push("STARVATION_PROTECTION")
  if (totalPenalties > 0.05 && debt.zone === "CRITICAL") reasonCodes.push("HIGH_FUTURE_MEMORY_COST")

  return {
    actionType: ActionType.ADVANCE_NODE,
    nodeId: node.nodeId,
    estimatedMinutes,
    baseScore,
    bonuses,
    penalties,
    finalScore,
    factorBreakdown: factors,
    reasonCodes,
    causalFit: 1.0,
    timeEfficiency: finalScore / Math.max(1, estimatedMinutes),
  }
}
