// ─── VALIDATION POLICY ──────────────────────────────────────
// Fonte: RETENTION-POLICY.spec.md (§24+ — seção VALIDATION)
// Policy ID: validate-policy@0.1.0

import {
  NodeDecisionState, ReviewDebtState, CandidateAction, ActionType,
  FactorBreakdown, BonusEntry, PenaltyEntry, EngineConstraints, NodeState,
} from "@mpc/domain"

function calcTimeFit(estimated: number, available: number): number {
  const ratio = estimated / available
  if (ratio <= 0.35) return 1.00
  if (ratio <= 0.60) return 0.90
  if (ratio <= 0.85) return 0.75
  if (ratio <= 1.00) return 0.60
  return 0.00
}

export function isValidationEligible(
  node: NodeDecisionState
): { eligible: boolean; reason: string | null } {
  if (node.state === NodeState.N0_NOT_SEEN) {
    return { eligible: false, reason: "NO_FOUNDATION" }
  }
  if (!node.availableAssets.hasQuestions && !node.availableAssets.hasFlashcards) {
    return { eligible: false, reason: "NO_DIAGNOSTIC_ASSETS" }
  }
  return { eligible: true, reason: null }
}

export function rankValidation(
  node: NodeDecisionState,
  availableMinutes: number,
  debt: ReviewDebtState,
  constraints: EngineConstraints,
  now: string
): CandidateAction | null {
  const eligibility = isValidationEligible(node)
  if (!eligibility.eligible) return null

  const estimatedMinutes = node.estimatedValidateMinutes
  const timeFit = calcTimeFit(estimatedMinutes, availableMinutes)
  if (timeFit <= 0 && estimatedMinutes > availableMinutes) return null

  const masteryUncertainty = node.masteryUncertainty ?? (1 - node.stateConfidence) * 0.6 + (node.A < 0.6 ? 0.4 : 0)
  const errorHistory = node.recentErrorScore ?? 0
  const timeSinceTest = node.daysSinceValidation !== null
    ? Math.min(1, node.daysSinceValidation / 30)
    : 1.0

  const factors: FactorBreakdown[] = [
    { factor: "objectiveWeight", value: node.objectiveWeight, weight: 0.30, contribution: 0.30 * node.objectiveWeight },
    { factor: "masteryUncertainty", value: masteryUncertainty, weight: 0.25, contribution: 0.25 * masteryUncertainty },
    { factor: "errorHistory", value: errorHistory, weight: 0.25, contribution: 0.25 * errorHistory },
    { factor: "timeSinceTest", value: timeSinceTest, weight: 0.10, contribution: 0.10 * timeSinceTest },
    { factor: "timeFit", value: timeFit, weight: 0.10, contribution: 0.10 * timeFit },
  ]

  const baseScore = factors.reduce((s, f) => s + f.contribution, 0)

  const bonuses: BonusEntry[] = []

  const transferGapScore = Math.max(0, (node.R - node.A) * 0.3)
  if (transferGapScore > 0.05) {
    const val = Math.min(0.15, transferGapScore)
    bonuses.push({ id: "BONUS-V-001", label: "Cards Good, Questions Bad", value: Math.round(val * 100) / 100 })
  }

  if (node.stateConfidence < 0.5 && (node.state === NodeState.N4_APPLICABLE || node.state === NodeState.N5_STABLE)) {
    bonuses.push({ id: "BONUS-V-002", label: "High State, Low Confidence", value: 0.08 })
  }

  if (node.R >= 0.7 && node.A < 0.5) {
    bonuses.push({ id: "BONUS-V-005", label: "No Application Evidence", value: 0.10 })
  }

  if (errorHistory >= 0.7 && node.highConfidenceErrorScore >= 0.5) {
    bonuses.push({ id: "BONUS-V-003", label: "Conflicting Evidence", value: 0.08 })
  }

  const penalties: PenaltyEntry[] = []

  if (node.daysSinceValidation !== null && node.daysSinceValidation <= 1) {
    penalties.push({ id: "PEN-V-001", label: "Recently Validated", value: 0.15 })
  }

  if (node.state === NodeState.N1_EXPOSED || node.state === NodeState.N0_NOT_SEEN) {
    if (node.estimatedValidateMinutes > 10) {
      penalties.push({ id: "PEN-V-002", label: "Insufficient Foundation", value: 0.20 })
    }
  }

  if (!node.availableAssets.hasQuestions) {
    penalties.push({ id: "PEN-V-003", label: "Asset Mismatch", value: 0.10 })
  }

  const totalBonuses = bonuses.reduce((s, b) => s + b.value, 0)
  const totalPenalties = penalties.reduce((s, p) => s + p.value, 0)

  const finalScore = Math.min(1, Math.max(0, baseScore + totalBonuses - totalPenalties))

  const reasonCodes: string[] = []
  if (masteryUncertainty >= 0.6) reasonCodes.push("MASTERY_UNCERTAIN")
  if (node.stateConfidence < 0.5) reasonCodes.push("LOW_STATE_CONFIDENCE")
  if (transferGapScore > 0.05) reasonCodes.push("APPLICATION_TRANSFER_GAP")
  if (node.R >= 0.7 && node.A < 0.5) reasonCodes.push("NO_APPLICATION_EVIDENCE")
  if (errorHistory >= 0.7) reasonCodes.push("RECENT_ERROR_PATTERN")
  if (timeSinceTest >= 0.7) reasonCodes.push("TIME_SINCE_VALIDATION_HIGH")

  return {
    actionType: ActionType.VALIDATE_NODE,
    nodeId: node.nodeId,
    estimatedMinutes,
    baseScore,
    bonuses,
    penalties,
    finalScore,
    factorBreakdown: factors,
    reasonCodes,
    causalFit: 1.0,
    timeEfficiency: finalScore / Math.max(1, estimatedMinutes),
  }
}
