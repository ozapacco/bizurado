// ─── RETENTION POLICY ───────────────────────────────────────
// Fonte: RETENTION-POLICY.spec.md (§1-23)
// Policy ID: retain-policy@0.1.0

import {
  NodeDecisionState, ReviewDebtState, CandidateAction, ActionType,
  FactorBreakdown, BonusEntry, PenaltyEntry, EngineConstraints,
  NodeState,
} from "@mpc/domain"

function calcTimeFit(estimated: number, available: number): number {
  const ratio = estimated / available
  if (ratio <= 0.35) return 1.00
  if (ratio <= 0.60) return 0.90
  if (ratio <= 0.85) return 0.75
  if (ratio <= 1.00) return 0.60
  return 0.00
}

export function isRetentionEligible(
  node: NodeDecisionState
): { eligible: boolean; reason: string | null } {
  if (node.state === NodeState.N0_NOT_SEEN) {
    return { eligible: false, reason: "NO_PRIOR_ACQUISITION" }
  }
  if (node.R >= 0.85 && node.A >= 0.80 && node.state === NodeState.N5_STABLE) {
    return { eligible: false, reason: "ALREADY_STABLE" }
  }
  if (!node.availableAssets.hasFlashcards) {
    return { eligible: false, reason: "NO_RETENTION_ASSETS" }
  }
  return { eligible: true, reason: null }
}

export function rankRetention(
  node: NodeDecisionState,
  availableMinutes: number,
  debt: ReviewDebtState,
  constraints: EngineConstraints,
  now: string
): CandidateAction | null {
  const eligibility = isRetentionEligible(node)
  if (!eligibility.eligible) return null

  const estimatedMinutes = node.estimatedRetainMinutes
  const timeFit = calcTimeFit(estimatedMinutes, availableMinutes)
  if (timeFit <= 0 && estimatedMinutes > availableMinutes) return null

  const forgettingRisk = node.forgettingRisk ?? (1 - node.R) * 0.7 + (1 - node.S) * 0.3
  const recentError = node.recentErrorScore ?? 0
  const confusability = node.confusabilityScore ?? 0

  const factors: FactorBreakdown[] = [
    { factor: "objectiveWeight", value: node.objectiveWeight, weight: 0.30, contribution: 0.30 * node.objectiveWeight },
    { factor: "forgettingRisk", value: forgettingRisk, weight: 0.30, contribution: 0.30 * forgettingRisk },
    { factor: "recentError", value: recentError, weight: 0.20, contribution: 0.20 * recentError },
    { factor: "confusability", value: confusability, weight: 0.10, contribution: 0.10 * confusability },
    { factor: "timeFit", value: timeFit, weight: 0.10, contribution: 0.10 * timeFit },
  ]

  const baseScore = factors.reduce((s, f) => s + f.contribution, 0)

  const bonuses: BonusEntry[] = []

  if (node.highConfidenceErrorScore >= 0.7) {
    const val = Math.min(0.10, node.highConfidenceErrorScore * 0.10)
    bonuses.push({ id: "BONUS-R-001", label: "High Confidence Error", value: Math.round(val * 100) / 100 })
  }
  if (node.confusabilityScore >= 0.7 && recentError > 0) {
    bonuses.push({ id: "BONUS-R-005", label: "Confusion Cluster", value: 0.06 })
  }
  if (forgettingRisk >= 0.7 && node.objectiveWeight >= 0.6) {
    bonuses.push({ id: "BONUS-R-003", label: "Critical Memory Class A", value: 0.06 })
  }

  const penalties: PenaltyEntry[] = []

  if (node.availableAssets.classARatio < 0.3) {
    penalties.push({ id: "PEN-R-001", label: "Peripheral Class C", value: 0.10 })
  }
  if (node.objectiveWeight < 0.3) {
    penalties.push({ id: "PEN-R-002", label: "Low Objective Weight", value: 0.08 })
  }
  if (node.daysSinceRetrieval !== null && node.daysSinceRetrieval <= 1) {
    penalties.push({ id: "PEN-R-003", label: "Redundant Review", value: 0.15 })
  }

  if (debt.zone === "CRITICAL") {
    penalties.push({ id: "PEN-R-001", label: "Peripheral Class C (Critical Debt)", value: 0.20 })
  }

  const totalBonuses = bonuses.reduce((s, b) => s + b.value, 0)
  const totalPenalties = penalties.reduce((s, p) => s + p.value, 0)

  const finalScore = Math.min(1, Math.max(0, baseScore + totalBonuses - totalPenalties))

  const reasonCodes: string[] = []
  if (forgettingRisk >= 0.7) reasonCodes.push("HIGH_FORGETTING_RISK")
  if (recentError >= 0.7) reasonCodes.push("HIGH_CONFIDENCE_ERROR")
  if (node.highConfidenceErrorScore >= 0.7) reasonCodes.push("RECENT_RETRIEVAL_FAILURE")
  if (confusability >= 0.7) reasonCodes.push("HIGH_CONFUSABILITY")
  if (timeFit >= 0.9) reasonCodes.push("GOOD_TIME_FIT")
  if (totalPenalties > 0.10) reasonCodes.push("PERIPHERAL_MEMORY")

  return {
    actionType: ActionType.RETAIN_NODE,
    nodeId: node.nodeId,
    estimatedMinutes,
    baseScore,
    bonuses,
    penalties,
    finalScore,
    factorBreakdown: factors,
    reasonCodes,
    causalFit: 1.0,
    timeEfficiency: finalScore / Math.max(1, estimatedMinutes),
  }
}
