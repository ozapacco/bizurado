// ─── PROGRESSION ENGINE ─────────────────────────────────────
// Fonte: PROGRESSION-ENGINE.spec.md
// Invariantes: ENG-INV-001 a ENG-INV-008
// TODO

import {
  EngineInput, EngineOutput, EnginePhase, CandidateAction,
  RankedCandidate, QueueSnapshots, NodeDecisionState,
  ReviewDebtState, DEFAULT_ENGINE_CONSTRAINTS,
  PHASE_COVERAGE_THRESHOLDS, NodeState,
} from "@mpc/domain"
import { rankAdvancement } from "./policies/advancement.js"
import { rankRetention } from "./policies/retention.js"
import { rankValidation } from "./policies/validation.js"
import { composeSession, ComposeSessionInput } from "./session-composer.js"
import type { SessionActionPlan, EngineDecision, InvariantCheckResult } from "@mpc/domain"

function computeInputHash(input: EngineInput): string {
  const str = JSON.stringify(input)
  let hash = 0
  for (let i = 0; i < str.length; i++) {
    const chr = str.charCodeAt(i)
    hash = ((hash << 5) - hash) + chr
    hash |= 0
  }
  return `hash_${Math.abs(hash).toString(16)}`
}

function calculateWeightedCoverage(nodes: NodeDecisionState[]): number {
  if (nodes.length === 0) return 0
  const totalWeight = nodes.reduce((s, n) => s + n.objectiveWeight, 0)
  if (totalWeight === 0) return 0
  const weighted = nodes.reduce((s, n) => {
    const stateValue: Record<string, number> = {
      [NodeState.N0_NOT_SEEN]: 0,
      [NodeState.N1_EXPOSED]: 0.2,
      [NodeState.N2_UNDERSTOOD]: 0.4,
      [NodeState.N3_RETRIEVABLE]: 0.6,
      [NodeState.N4_APPLICABLE]: 0.8,
      [NodeState.N5_STABLE]: 0.9,
      [NodeState.N6_EXAM_READY]: 1.0,
    }
    return s + n.objectiveWeight * (stateValue[n.state] ?? 0)
  }, 0)
  return weighted / totalWeight
}

function detectEnginePhase(
  weightedCoverage: number,
  debt: ReviewDebtState,
  daysSinceLastSession: number | null,
  targetDate: string | null,
  now: string
): EnginePhase {
  if (daysSinceLastSession !== null && daysSinceLastSession > 5) return "RECOVERY" as EnginePhase
  if (targetDate) {
    const daysUntilExam = (new Date(targetDate).getTime() - new Date(now).getTime()) / 86400000
    if (daysUntilExam <= 30 && daysUntilExam > 0) return "PRE_EXAM" as EnginePhase
  }
  if (weightedCoverage < PHASE_COVERAGE_THRESHOLDS.LOW_COVERAGE) return "LOW_COVERAGE" as EnginePhase
  if (weightedCoverage > PHASE_COVERAGE_THRESHOLDS.HIGH_COVERAGE) return "HIGH_COVERAGE" as EnginePhase
  return "MID_COVERAGE" as EnginePhase
}

function toRanked(candidates: CandidateAction[]): RankedCandidate[] {
  return candidates
    .filter((c): c is CandidateAction => c !== null)
    .sort((a, b) => b.finalScore - a.finalScore)
    .map((c, i): RankedCandidate => ({ ...c, rank: i + 1 }))
}

export function generateSession(input: EngineInput): EngineOutput {
  const { availableMinutes, nodes, reviewDebt, objective, sessionHistory, now } = input
  const constraints = input.constraints ?? DEFAULT_ENGINE_CONSTRAINTS

  const weightedCoverage = calculateWeightedCoverage(nodes)
  const phase = detectEnginePhase(
    weightedCoverage,
    reviewDebt,
    sessionHistory.daysSinceLastSession,
    objective.targetDate,
    now
  )

  const advanceCandidates: CandidateAction[] = nodes
    .map(n => rankAdvancement(n, availableMinutes, reviewDebt, constraints, now))
    .filter((c): c is CandidateAction => c !== null)

  const retainCandidates: CandidateAction[] = nodes
    .map(n => rankRetention(n, availableMinutes, reviewDebt, constraints, now))
    .filter((c): c is CandidateAction => c !== null)

  const validateCandidates: CandidateAction[] = nodes
    .map(n => rankValidation(n, availableMinutes, reviewDebt, constraints, now))
    .filter((c): c is CandidateAction => c !== null)

  const rankedAdvance = toRanked(advanceCandidates)
  const rankedRetain = toRanked(retainCandidates)
  const rankedValidate = toRanked(validateCandidates)

  const queueSnapshots: QueueSnapshots = {
    advance: rankedAdvance,
    retain: rankedRetain,
    validate: rankedValidate,
  }

  const composeInput: ComposeSessionInput = {
    rankedAdvance: rankedAdvance,
    rankedRetain: rankedRetain,
    rankedValidate: rankedValidate,
    availableMinutes,
    phase,
    debt: reviewDebt,
    constraints,
    userId: input.userId,
    objectiveId: input.objectiveId,
    engineVersion: input.engineVersion,
    policyVersion: input.policyVersion,
    now,
  }

  const composed = composeSession(composeInput)

  const inputHash = computeInputHash(input)

  return {
    sessionPlan: {
      ...composed.sessionPlan,
      actions: composed.sessionPlan.actions,
    },
    queueSnapshots,
    decisions: composed.decisions,
    invariantChecks: composed.invariantChecks,
    engineVersion: input.engineVersion,
    policyVersion: input.policyVersion,
    inputHash,
    phase,
  }
}
