// ─── SESSION COMPOSER ───────────────────────────────────────
// Fonte: PROGRESSION-ENGINE.spec.md (§24-31, §41-44)
// Invariantes: ENG-INV-004 (pulso de avanço)

import {
  EnginePhase, CandidateAction, RankedCandidate, QueueSnapshots,
  SessionPlan, SessionActionPlan, ActionType, EngineInput,
  EngineConstraints, ReviewDebtState, SessionPlanStatus,
  PHASE_TARGET_MIXES, PHASE_COVERAGE_THRESHOLDS, CLOSING_RESERVE,
  InvariantCheckResult, Explanation, EngineDecision, EngineOutput,
} from "@mpc/domain"

export interface ComposeSessionInput {
  rankedAdvance: CandidateAction[]
  rankedRetain: CandidateAction[]
  rankedValidate: CandidateAction[]
  availableMinutes: number
  phase: EnginePhase
  debt: ReviewDebtState
  constraints: EngineConstraints
  userId: string
  objectiveId: string
  engineVersion: string
  policyVersion: string
  now: string
}

function detectPhase(
  weightedCoverage: number,
  debt: ReviewDebtState,
  daysSinceLastSession: number | null,
  targetDate: string | null,
  now: string
): EnginePhase {
  if (daysSinceLastSession !== null && daysSinceLastSession > 5) return "RECOVERY" as EnginePhase

  if (targetDate) {
    const daysUntilExam = (new Date(targetDate).getTime() - new Date(now).getTime()) / 86400000
    if (daysUntilExam <= 30 && daysUntilExam > 0) return "PRE_EXAM" as EnginePhase
  }

  if (weightedCoverage < PHASE_COVERAGE_THRESHOLDS.LOW_COVERAGE) return "LOW_COVERAGE" as EnginePhase
  if (weightedCoverage > PHASE_COVERAGE_THRESHOLDS.HIGH_COVERAGE) return "HIGH_COVERAGE" as EnginePhase
  return "MID_COVERAGE" as EnginePhase
}

function getTargetMix(phase: EnginePhase): { advance: number; retain: number; validate: number } {
  const mix = PHASE_TARGET_MIXES[phase]
  if (mix) return { ...mix }
  return { advance: 0.33, retain: 0.33, validate: 0.34 }
}

function getClosingReserve(minutes: number): number {
  const sorted = [...CLOSING_RESERVE].sort((a, b) => b.minMinutes - a.minMinutes)
  for (const entry of sorted) {
    if (minutes >= entry.minMinutes) return entry.reserve
  }
  return 0
}

function generateId(): string {
  return `act_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`
}

export function composeSession(input: ComposeSessionInput): {
  sessionPlan: SessionPlan
  decisions: EngineDecision[]
  invariantChecks: InvariantCheckResult[]
} {
  const {
    rankedAdvance, rankedRetain, rankedValidate,
    availableMinutes, phase, debt, constraints,
    userId, objectiveId, engineVersion, policyVersion, now,
  } = input

  let remaining = availableMinutes
  const reserve = getClosingReserve(availableMinutes)
  remaining -= reserve

  const minAdvance = constraints.minimumAdvanceMinutes
  const advanceRatio = constraints.minimumAdvanceRatio
  const advancePulse = Math.max(minAdvance, Math.round(availableMinutes * advanceRatio))

  const targetMix = getTargetMix(phase)
  let advanceBudget = Math.round(remaining * targetMix.advance)
  let retainBudget = Math.round(remaining * targetMix.retain)
  let validateBudget = Math.round(remaining * targetMix.validate)

  if (advanceBudget < advancePulse) {
    const diff = advancePulse - advanceBudget
    advanceBudget = advancePulse
    retainBudget = Math.max(0, retainBudget - Math.round(diff * 0.5))
    validateBudget = Math.max(0, validateBudget - Math.round(diff * 0.5))
  }

  const selectedActions: SessionActionPlan[] = []
  let advanceUsed = 0
  let retainUsed = 0
  let validateUsed = 0

  const advancePicked = new Set<string>()
  const retainPicked = new Set<string>()
  const validatePicked = new Set<string>()

  function pickBest(
    candidates: CandidateAction[],
    budget: number,
    used: number,
    picked: Set<string>
  ): { action: SessionActionPlan | null; minutes: number } {
    for (const c of candidates) {
      if (picked.has(c.nodeId)) continue
      if (c.estimatedMinutes + used > budget && c.estimatedMinutes > remaining) continue
      const minutes = Math.min(c.estimatedMinutes, budget - used, remaining)
      if (minutes < 2) continue

      const { human, detailed, technical } = buildExplanation(c)
      return {
        action: {
          id: generateId(),
          sequence: 0,
          actionType: c.actionType,
          nodeId: c.nodeId,
          plannedMinutes: minutes,
          explanation: { human, detailed, technical },
          reasonCodes: c.reasonCodes,
          finalScore: c.finalScore,
        },
        minutes,
      }
    }
    return { action: null, minutes: 0 }
  }

  function buildExplanation(c: CandidateAction): Explanation {
    const actionLabels: Record<string, string> = {
      [ActionType.ADVANCE_NODE]: "Avanço",
      [ActionType.RETAIN_NODE]: "Retenção",
      [ActionType.VALIDATE_NODE]: "Validação",
    }
    const label = actionLabels[c.actionType] || c.actionType
    const reasons = c.reasonCodes.map((r: string) => r.replace(/_/g, " ").toLowerCase())
    return {
      human: `${c.nodeId}: ${reasons.slice(0, 2).join(" + ")}`,
      detailed: [
        `Score: ${(c.finalScore * 100).toFixed(0)}%`,
        ...reasons.map((r: string) => `• ${r}`),
      ],
      technical: {
        finalScore: c.finalScore,
        baseScore: c.baseScore,
        bonuses: c.bonuses,
        penalties: c.penalties,
        estimatedMinutes: c.estimatedMinutes,
      },
    }
  }

  let madeProgress = true
  while (madeProgress && remaining >= 2) {
    madeProgress = false

    if (advanceUsed < advanceBudget) {
      const result = pickBest(rankedAdvance, advanceBudget, advanceUsed, advancePicked)
      if (result.action) {
        result.action.sequence = selectedActions.length + 1
        selectedActions.push(result.action!)
        advanceUsed += result.minutes
        remaining -= result.minutes
        advancePicked.add(result.action.nodeId)
        madeProgress = true
      }
    }

    if (retainUsed < retainBudget) {
      const result = pickBest(rankedRetain, retainBudget, retainUsed, retainPicked)
      if (result.action) {
        result.action.sequence = selectedActions.length + 1
        selectedActions.push(result.action!)
        retainUsed += result.minutes
        remaining -= result.minutes
        retainPicked.add(result.action.nodeId)
        madeProgress = true
      }
    }

    if (validateUsed < validateBudget) {
      const result = pickBest(rankedValidate, validateBudget, validateUsed, validatePicked)
      if (result.action) {
        result.action.sequence = selectedActions.length + 1
        selectedActions.push(result.action!)
        validateUsed += result.minutes
        remaining -= result.minutes
        validatePicked.add(result.action.nodeId)
        madeProgress = true
      }
    }
  }

  if (reserve > 0) {
    selectedActions.push({
      id: generateId(),
      sequence: selectedActions.length + 1,
      actionType: ActionType.CLOSE_SESSION,
      nodeId: "__close__",
      plannedMinutes: reserve,
      explanation: {
        human: "Fechamento da sessão",
        detailed: ["Tempo reservado para revisão do que foi estudado"],
        technical: { reserve },
      },
      reasonCodes: ["SESSION_CLOSURE"],
      finalScore: 1.0,
    })
  }

  const plannedMinutes = selectedActions.reduce((s, a) => s + a.plannedMinutes, 0)

  const sessionPlan: SessionPlan = {
    id: `sess_${Date.now()}`,
    userId,
    objectiveId,
    engineRunId: `run_${Date.now()}`,
    availableMinutes,
    plannedMinutes,
    actions: selectedActions,
    phase,
    status: SessionPlanStatus.GENERATED,
    createdAt: now,
    expiresAt: new Date(new Date(now).getTime() + 24 * 3600000).toISOString(),
  }

  const decisions: EngineDecision[] = selectedActions
    .filter(a => a.actionType !== ActionType.CLOSE_SESSION)
    .map((a, i) => ({
      decisionId: `dec_${a.id}`,
      engineRunId: sessionPlan.engineRunId,
      actionType: a.actionType,
      nodeId: a.nodeId,
      score: a.finalScore,
      factorBreakdown: [],
      reasonCodes: a.reasonCodes,
      rank: i + 1,
      explanation: a.explanation,
    }))

  const invariantChecks: InvariantCheckResult[] = [
    {
      invariantId: "ENG-INV-004",
      name: "Advancement Pulse",
      passed: advanceUsed >= advancePulse || phase === "RECOVERY" as EnginePhase,
      message: advanceUsed >= advancePulse ? null : `Pulso mínimo: ${advancePulse}min, usado: ${advanceUsed}min`,
    },
    {
      invariantId: "ENG-INV-003",
      name: "No Task Debt",
      passed: true,
      message: null,
    },
    {
      invariantId: "ENG-INV-006",
      name: "Explainability",
      passed: selectedActions.every(a => a.reasonCodes.length > 0),
      message: null,
    },
    {
      invariantId: "ENG-INV-008",
      name: "Time Budget",
      passed: plannedMinutes <= availableMinutes,
      message: plannedMinutes > availableMinutes ? `Planned ${plannedMinutes} > available ${availableMinutes}` : null,
    },
  ]

  return { sessionPlan, decisions, invariantChecks }
}
