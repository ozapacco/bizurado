// ─── CAPACITY MODEL ─────────────────────────────────────────
// Fonte: PRD (§27), CONSTITUTION (§4 INV-005)
// Método inicial: Média móvel exponencial (EMA)

import { CapacityProfile, CapacityObservation } from "@mpc/domain"

export interface CapacityModelInput {
  observations: CapacityObservation[]
  alpha?: number
}

export function calculateExponentialMovingAverage(
  values: number[],
  alpha: number = 0.3
): number {
  if (values.length === 0) return 0
  let ema = values[0]
  for (let i = 1; i < values.length; i++) {
    ema = alpha * values[i] + (1 - alpha) * ema
  }
  return ema
}

export function calculateVariance(
  values: number[],
  mean: number
): number {
  if (values.length <= 1) return 0
  const sqDiffs = values.map(v => (v - mean) ** 2)
  return sqDiffs.reduce((s, d) => s + d, 0) / (values.length - 1)
}

export function runCapacityModel(
  input: CapacityModelInput
): CapacityProfile {
  const { observations, alpha = 0.3 } = input

  if (observations.length === 0) {
    return {
      userId: "",
      expectedDailyMinutes: 0,
      expectedWeeklyMinutes: 0,
      variance: 0,
      confidence: 0,
      calculatedAt: new Date().toISOString(),
      modelVersion: "ema@0.1.0",
    }
  }

  const userId = observations[0].userId
  const dailyMinutes = observations.map(o => o.studiedMinutes)
  const ema = calculateExponentialMovingAverage(dailyMinutes, alpha)
  const variance = calculateVariance(dailyMinutes, ema)

  const nonZeroDays = observations.filter(o => !o.zeroDay).length
  const confidence = Math.min(
    1.0,
    (nonZeroDays / Math.max(1, observations.length)) * 0.5 + 0.3 + (observations.length > 10 ? 0.2 : 0)
  )

  return {
    userId,
    expectedDailyMinutes: Math.round(ema),
    expectedWeeklyMinutes: Math.round(ema * 7),
    variance: Math.round(variance),
    confidence: Math.round(confidence * 100) / 100,
    calculatedAt: new Date().toISOString(),
    modelVersion: "ema@0.1.0",
  }
}
